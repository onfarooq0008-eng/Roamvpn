package com.roamvpn.data

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

/** Result of registering this device with a server via the control API. */
data class BackendRegistration(
    val serverId: String,
    val endpointHost: String,
    val endpointPort: Int,
    val serverPublicKey: String,
    val dns: String,
    val assignedAddress: String,
    val created: Boolean,
    val registrationToken: String
)

/**
 * Talks to your /backend control API (see that folder for the server-side
 * code). AppSettings.backendApiUrl is always set in a real build (it falls
 * back to the compiled-in BuildConfig.DEFAULT_BACKEND_API_URL), so this is
 * the app's only path for fetching servers and registering devices.
 */
class BackendApiClient {

    private companion object {
        // ONE client for the whole process: OkHttp pools connections and threads per client, so
        // creating a new client for every ServerSource()/BackendApiClient() threw that reuse away
        // (a fresh TLS handshake for every request, plus extra idle thread pools).
        //
        // Timeouts are kept short on purpose: the server list re-polls every 30s while the app is
        // open (see MainActivity.SERVER_REFRESH_INTERVAL_MS), so an unreachable backend should fail
        // fast and let the next tick try again. callTimeout bounds the whole request (DNS + connect
        // + TLS + body), which the per-phase timeouts alone do not.
        val client: OkHttpClient by lazy {
            OkHttpClient.Builder()
                .connectTimeout(5, TimeUnit.SECONDS)
                .readTimeout(6, TimeUnit.SECONDS)
                .writeTimeout(6, TimeUnit.SECONDS)
                .callTimeout(10, TimeUnit.SECONDS)
                .build()
        }
    }

    suspend fun fetchServers(baseUrl: String): List<Server> = withContext(Dispatchers.IO) {
        val request = Request.Builder().url("${baseUrl.trimEnd('/')}/api/servers").get().build()
        client.newCall(request).execute().use { response ->
            if (!response.isSuccessful) throw java.io.IOException("HTTP ${response.code}")
            val body = response.body?.string() ?: throw java.io.IOException("Empty response")
            val array = JSONArray(body)
            (0 until array.length()).map { i ->
                val o = array.getJSONObject(i)
                Server(
                    id = o.getString("id"),
                    name = o.optString("name", o.optString("countryName")),
                    countryName = o.optString("countryName"),
                    countryCode = o.optString("countryCode", "US"),
                    city = o.optString("city"),
                    endpointHost = o.getString("endpointHost"),
                    endpointPort = o.optInt("endpointPort", 51820),
                    serverPublicKey = o.getString("serverPublicKey"),
                    dns = o.optString("dns", "1.1.1.1"),
                    streaming = o.optBoolean("streaming", false)
                )
            }
        }
    }

    /** The public IP address the backend sees for this device. While the VPN is up this is the
     *  server's exit IP, which is what the Home screen shows as "IP Address". */
    suspend fun fetchMyIp(baseUrl: String): String = withContext(Dispatchers.IO) {
        val request = Request.Builder().url("${baseUrl.trimEnd('/')}/api/myip").get().build()
        client.newCall(request).execute().use { response ->
            if (!response.isSuccessful) throw java.io.IOException("HTTP ${response.code}")
            val body = response.body?.string() ?: throw java.io.IOException("Empty response")
            JSONObject(body).getString("ip")
        }
    }

    suspend fun register(baseUrl: String, devicePublicKeyBase64: String, preferredServerId: String?): BackendRegistration =
        withContext(Dispatchers.IO) {
            val json = JSONObject().apply {
                put("devicePublicKey", devicePublicKeyBase64)
                if (preferredServerId != null) put("preferredServerId", preferredServerId)
            }
            val body = json.toString().toRequestBody("application/json".toMediaType())
            val request = Request.Builder()
                .url("${baseUrl.trimEnd('/')}/api/register")
                .post(body)
                .build()
            client.newCall(request).execute().use { response ->
                val responseBody = response.body?.string() ?: throw java.io.IOException("Empty response")
                if (!response.isSuccessful) {
                    val err = runCatching { JSONObject(responseBody).optString("error") }.getOrNull()
                    throw java.io.IOException(err ?: "HTTP ${response.code}")
                }
                val o = JSONObject(responseBody)
                BackendRegistration(
                    serverId = o.getString("serverId"),
                    endpointHost = o.getString("endpointHost"),
                    endpointPort = o.optInt("endpointPort", 51820),
                    serverPublicKey = o.getString("serverPublicKey"),
                    dns = o.optString("dns", "1.1.1.1"),
                    assignedAddress = o.getString("assignedAddress"),
                    created = o.optBoolean("created", false),
                    registrationToken = o.optString("registrationToken", "")
                )
            }
        }

    suspend fun unregister(baseUrl: String, devicePublicKeyBase64: String, serverId: String, registrationToken: String) =
        withContext(Dispatchers.IO) {
            val json = JSONObject().apply {
                put("devicePublicKey", devicePublicKeyBase64)
                put("serverId", serverId)
                put("registrationToken", registrationToken)
            }
            val body = json.toString().toRequestBody("application/json".toMediaType())
            val request = Request.Builder()
                .url("${baseUrl.trimEnd('/')}/api/unregister")
                .post(body)
                .build()
            client.newCall(request).execute().use { response ->
                val responseBody = response.body?.string().orEmpty()
                if (!response.isSuccessful) {
                    val err = runCatching { JSONObject(responseBody).optString("error") }.getOrNull()
                    throw java.io.IOException(err ?: "HTTP ${response.code}")
                }
            }
        }

}
